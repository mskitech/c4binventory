<!-- Content Wrapper. Contains page content  -->
<div class="content-wrapper">
 <!-- Main content -->
          <section class="content mt-5">
            <div class="container-fluid">
             <div class="card-header">
                <h3 class="card-title mt-3">Add Catagory catagory</h3>
              </div>
              <!-- /.card-header -->
               <div class="row">
                 <div class="col-md-8 offset-md-2 col-lg-8 offset-lg-2 mt-3">
                   <div class="card">
                     <div class="card-body">
                <form id="addexpenseCat">
                    <div class="form-group">
                        <label for="expense_catName">Expene Catagory name</label>
                        <input type="text" class="form-control" id="expense_catName" name="expense_catName" placeholder="Expense catagory name">
                    </div>
                            <div class="form-group">
                            <label for="expesecatDescrip">description </label>
                            <textarea  rows="3" class="form-control" id="expesecatDescrip" name="expesecatDescrip"></textarea>
                          </div>
                          <div class="form-group">
                            <button type="submit" class="btn btn-primary btn-block mt-4 rounded-0">Update</button>
                          </div>
                        </form>
                      </div>
                  </div>
                 </div>
               </div>
            </div>
            <!-- /.card-body -->
            <!-- /.row -->
            </div><!--/. container-fluid -->
          </section>
          <!-- /.content -->
        </div>
        <!-- /.content-wrapper