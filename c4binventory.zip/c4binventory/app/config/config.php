<?php
// setting time zone
date_default_timezone_set("Africa/Kampala");

// define the site root
define('SITE_ROOT', 'http://localhost/c4binventory/');



// Database Information
// Database Hostname
define('DATABASE_HOST','localhost');
// Database Username
define('DATABASE_USER','root');
// Database Name
define('DATABASE_NAME', 'ample');
// Database DB_PASS
define('DATABASE_PASS','');


 ?>
